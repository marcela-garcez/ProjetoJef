package com.curso.suporteos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuporteosApplicationTests {

	@Test
	void contextLoads() {
	}

}
